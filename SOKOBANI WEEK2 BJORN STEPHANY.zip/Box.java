public class Box extends GameObject {

    Position position;
    Box(Position position) {
        super(position);
    }

    @Override
    String getSymbol() {
        return "B";
    }
    
}
