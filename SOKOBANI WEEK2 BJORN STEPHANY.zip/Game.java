import java.util.ArrayList;

public class Game {
    public static void main(String[] args) {
        System.out.println("\nSokobani starts!\n");

        // Step 2.4
        Position position = new Position(0, 0);
        Player player = new Player(position, 5, 5);

        Position boxPosition = new Position(1, 1);
        Box box = new Box(boxPosition);

        Position wallOnePosition = new Position(2, 2);
        Wall wallOne = new Wall(wallOnePosition);

        Position wallTwoPosition = new Position(3, 3);
        Wall wallTwo = new Wall(wallTwoPosition);

        Position wallThreePosition = new Position(4, 4);
        Wall wallThree = new Wall(wallThreePosition);

        ArrayList<GameObject> objects = new ArrayList<>();
        objects.add(player);
        objects.add(box);
        objects.add(wallOne);
        objects.add(wallTwo);
        objects.add(wallThree);

        printGrid(5, objects);

    }

    public static void printGrid(int gridSize, ArrayList<GameObject> objects) {
        for (int x = 0; x < gridSize; x++) {
            for (int y = 0; y < gridSize; y++) {
                boolean found = false;
                for (GameObject object : objects) {
                    if (object.isAt(x, y)) {
                        System.out.print(object.getSymbol());
                        found = true;
                        break;
                    }
                }
                if(!found) {
                    System.out.print(" . ");
                }
            }
            System.out.println();
        }
    }
}
