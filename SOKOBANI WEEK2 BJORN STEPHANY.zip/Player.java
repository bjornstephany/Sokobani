public class Player extends GameObject{

    //map dimensions
    public int gridWidth;
    public int gridHeight;

    //starting position constructor
    Player(Position position, int width, int height) {
        super(position);
        gridWidth = width;
        gridHeight = height;
    }

    @Override
    String getSymbol() {
        return "P";
    }

    public boolean inBounds(int x, int y) {
        if (x >= 0 && x <= gridWidth - 1 && y >= 0 && y <= gridHeight - 1) return true;
        return false;
    }

    //movement methods
    public void moveUp() {
        if (inBounds(position.getX(), position.getY() - 1)) {
            position.setY(position.getY() - 1);
        } else {
            System.out.println("You can't move outside the map!");
        }
    }
    public void moveDown() {
        if (inBounds(position.getX(), position.getY() + 1)) {
            position.setY(position.getY() + 1);
        } else {
            System.out.println("You can't move outside the map!");
        }
    }
    public void moveRight() {
        if (inBounds(position.getX() + 1, position.getY())) {
            position.setX(position.getX() + 1);
        } else {
            System.out.println("You can't move outside the map!");
        }
    }
    public void moveLeft() {
        if (inBounds(position.getX() - 1, position.getY())) {
            position.setX(position.getX() - 1);
        } else {
            System.out.println("You can't move outside the map!");
        }
    }
}
