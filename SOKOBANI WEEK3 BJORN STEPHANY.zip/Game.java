import java.util.ArrayList;
import java.util.Scanner;

public class Game {

    static ArrayList<GameObject> objects = new ArrayList<>();

    static Position position = new Position(4, 4);
    static Player player = new Player(position, 9, 9);

    static Position boxPosition = new Position(1, 1);
    static Box box = new Box(boxPosition);

    static Position wallOnePosition = new Position(2, 2);
    static Wall wallOne = new Wall(wallOnePosition);

    static Position wallTwoPosition = new Position(3, 3);
    static Wall wallTwo = new Wall(wallTwoPosition);

    static Position wallThreePosition = new Position(5, 5);
    static Wall wallThree = new Wall(wallThreePosition);

    public static void main(String[] args) {

        objects.add(player);
        objects.add(box);
        objects.add(wallOne);
        objects.add(wallTwo);
        objects.add(wallThree);

        Scanner scanner = new Scanner(System.in);

        System.out.println("\nSokobani starts!\n");
        printGrid(objects);
        while (true) {
            System.out.print("Enter move (w/a/s/d):\n> ");
            String input = scanner.nextLine();
            if (input.equals("w")) {
                movePlayer(0, -1);
                printGrid(objects);
            }
            if (input.equals("a")) {
                movePlayer(-1, 0);
                printGrid(objects);
            }
            if (input.equals("s")) {
                movePlayer(0, 1);
                printGrid(objects);
            }
            if (input.equals("d")) {
                movePlayer(1, 0);
                printGrid(objects);
            }
            if (input.equals("q")) {
                return;
            }
        }
    }

    public static void movePlayer(int dx, int dy) {
        // Target x and y coordinates

        // What is the difference between player.position and position?
        int targetX = player.position.getX() + dx;
        int targetY = player.position.getY() + dy;

        GameObject object = getObjectAt(targetX, targetY);

        // If the target tile is empty move the player
        if (object == null) {
            player.move(dx, dy);
            return;
        }

        if (object instanceof Wall) {
            System.out.println("Wall");
            return;
        }

        if (object instanceof Box) {
            // Calculate the space behind the box
            int boxTargetX = targetX + dx;
            int boxTargetY = targetY + dy;
            GameObject boxTarget = getObjectAt(boxTargetX, boxTargetY);
            // If that space is empty, move the box, then move the player
            if (boxTarget == null && inBounds(boxTargetX, boxTargetY)) {
                ((Box)object).move(dx, dy);
                player.move(dx, dy);
                return;
            }
        }
    }

    // GET OBJECT AT
    static GameObject getObjectAt(int x, int y) {
        for (GameObject object : objects) {
            if (object.isAt(x, y)) {
                return object;
            }
        }
        return null;
    }

    // PRINT GRID
    public static void printGrid(ArrayList<GameObject> objects) {
        for (int x = 0; x < player.gridHeight; x++) {
            for (int y = 0; y < player.gridWidth; y++) {
                GameObject object = getObjectAt(y, x);
                if (object == null) {
                    System.out.print(" . ");
                } else {
                    System.out.print(" " + object.getSymbol() + " ");
                }
            }
            System.out.println();
        }
    }

    // IN BOUNDS (repeated method...)
    public static boolean inBounds(int x, int y) {
        if (x >= 0 && x <= player.gridWidth - 1 && y >= 0 && y <= player.gridHeight - 1)
            return true;
        return false;
    }

    // TO DO
    void interact(GameObject source, int dx, int dy) {

    }
}
