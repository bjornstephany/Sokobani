public class Player extends GameObject implements Movable{

    //map dimensions
    public int gridWidth;
    public int gridHeight;

    //starting position constructor
    Player(Position position, int width, int height) {
        super(position);
        gridWidth = width;
        gridHeight = height;
    }

    @Override
    String getSymbol() {
        return "P";
    }

    @Override
    public void move(int dx, int dy) {
        int targetX = position.getX() + dx;
        int targetY = position.getY() + dy;
        if (inBounds(targetX, targetY)) {
            position.setX(targetX);
            position.setY(targetY);
        } else {
            System.out.println("out of bounds");
        }
    }

    public boolean inBounds(int x, int y) {
        if (x >= 0 && x <= gridWidth - 1 && y >= 0 && y <= gridHeight - 1) return true;
        return false;
    }
}
