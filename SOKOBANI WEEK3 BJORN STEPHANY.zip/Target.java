public class Target extends GameObject {

    Position position;
    Target(Position position) {
        super(position);
    }
    @Override
    String getSymbol() {
        return "T";
    }
}
